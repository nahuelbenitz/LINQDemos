﻿using LINQDemos;
using LINQDemos.Models;
using LINQDemos.Utils;


#region Action

//void SayHello(string name)
//{
//    Console.WriteLine(name);
//}

//Action sayHello = () => Console.WriteLine("Hello");

//sayHello();



#endregion

#region Func

//double GetPI()
//{
//    return 3.1416;
//}

//Func<double> getPI = () => 3.1416;

//var result1 = getPI();

//Console.WriteLine(result1);

//double Add(double arg1, double arg2)
//{
//    return arg1 + arg2;
//}

//Func<double, double, double> add = (arg1, arg2) => arg1 + arg2;

//var result2 = add(2, 2);
//Console.WriteLine(result2);

#endregion

#region Select

////1.- Selecciona todos los nombres (sin apellidos) de los estudiantes
//IEnumerable<string> names =
//    DBContext.Students.Select((student) => student.FirstName);

//var names =
//    from n in DBContext.Students
//    select n.FirstName;

////2.- Selecciona todos los nombres y apellidos de los estudiantes
//var fullNames =
//    DBContext.Students.Select((student) => new
//    {
//        FirstName = student.FirstName,
//        LastName = student.LastName
//    });

//var names =
//    from n in DBContext.Students
//    select new { n.FirstName, n.LastName };

//foreach (var item in fullNames)
//{
//    Console.WriteLine($"{item.FirstName} {item.LastName}");
//}

#endregion


#region Deferred execution


//var names = DBContext.Students.Select(s => s.FirstName);

//DBContext.Students[0] = new Student
//{
//    FirstName = "New",
//    LastName = "Student",
//    Id = 100,
//    UniversityId = 10
//};

//Console.WriteLine("==============");
//foreach (var item in names)
//{
//    Console.WriteLine(item);
//}

#endregion

#region Where
//3.- Selecciona el nombre de todas las universidades dentro de USA
//var USAUniversities =
//    DBContext.Universities
//    .Where((university) => university.Country == "USA")
//    .Select(university => university.Name);

//var USAUniversities =
//    from u in DBContext.Universities
//    where u.Country == "USA"
//    select u.Name;

//foreach(var item in USAUniversities)
//{
//    Console.WriteLine(item);
//}
#endregion

#region OrderBy

//4.- Selecciona el nombre de todas las universidades ordenadas por nombre
//var USAUniversities =
//    DBContext.Universities
//    .OrderBy(u => u.Name)    
//    .Select(u => u.Name);

//var USAUniversities =
//    from u in DBContext.Universities
//    orderby u.Name descending
//    select u.Name;



//5.- Selecciona el nombre de todas las universidades ordenadas por nombre de forma ascendente,
//primero por país y luego por nombre
//var USAUniversities =
//    DBContext.Universities
//    .OrderBy(u => u.Country)
//    .ThenBy(u => u.Name)
//    .Select(u => u.Name);

//var USAUniversities =
//    from u in DBContext.Universities
//    orderby u.Country, u.Name
//    select u.Name;

#endregion

#region GroupBy

//6.- Utilizando agrupaciones, imprime el nombre del nombre del país y el número de universidades que hay en ese país,
//y a continuación el nombre de cada universidad en ese país en un formato de lista

//var universitiesByCountry =
//    DBContext.Universities
//    .GroupBy(u => u.Country);

//var universitiesByCountry =
//    from u in DBContext.Universities
//    group u by u.Country;

//foreach(var item in universitiesByCountry)
//{
//    Console.WriteLine(item);
//}

//foreach (var group in universitiesByCountry)
//{
//    Console.WriteLine($"Universidad en {group.Key}: {group.Count()}");
//    foreach (var university in group)
//    {
//        Console.WriteLine($"\t # {university.Name}");
//    }
//}

#endregion

#region Count

//7.- Imprime la cantidad de universidades en Canadá
//var universitiesInCanada =
//    DBContext.Universities
//    .Where(u => u.Country == "Canada")
//    .Count();

//var universitiesInCanada =
//    (from u in DBContext.Universities
//         where u.Country == "Canada"
//             select u).Count();

#endregion

#region Distinct

//8.- Imprime la cantidad de países en los que hay universidades

//var countryQuantity =
//    DBContext.Universities
//    .Select(u => u.Country)
//    .Distinct()
//    .Count();

//var countryQuantity =
//    (from u in DBContext.Universities
//         select u.Country).Distinct().Count();

#endregion

#region Join

//9.- Imprime el Nombre, apellido y país de universidad de todos los estudiantes

//var join =
//    DBContext.Students
//    .Join(DBContext.Universities,
//        s => s.UniversityId,
//        u => u.Id,
//        (s, u) => new { s.FirstName, s.LastName, u.Country });

//var join =
//    from s in DBContext.Students
//    join u in DBContext.Universities
//        on s.UniversityId equals u.Id
//    select new { s.FirstName, s.LastName, u.Country };


#endregion

#region More examples

#region Partitioning data
//1.- Obtén los dos primeros objetos de estudiantes de la lista
var firstTwoStudents =
        DBContext.Students.Take(2);

//2.- Obten el tercer y cuarto objeto de estudiantes de la lista
var thirdAndFifthStudents =
        DBContext.Students.Skip(2).Take(2);
#endregion

#region Quantifier operations

//3.- Obtén el valor booleano que indique si hay algún estudiante con el apellido "Peterson"
var anyPeterson =
        DBContext.Students.Any(s => s.LastName == "Peterson");

//4.- Obtén el valor booleano que indique si todos los estudiantes tienen un apellido
var allHaveLastName =
        DBContext.Students.All(s => !string.IsNullOrEmpty(s.LastName));

#endregion



#region First & FirstOrDefault
//5.- Obten el primer estudiante que tenga el apellido "Williams"
//var firstWilliams =
//        DBContext.Students.First(s => s.LastName == "Peterson");

//var firstWilliams2 =
//        DBContext.Students.FirstOrDefault(s => s.LastName == "Williams");
//if(firstWilliams2 != null)
//{
//    Console.WriteLine(firstWilliams2.FirstName);
//}

#endregion


#region SelectMany
//6.- Obtén una primer colección de estudiantes cuyo nombre empiece con la letra "J"
// Después, obtén una segunda colección de estudiantes cuyo nombre empiece con la letra "A"
// A continuación, crea una nueva lista de listas de estudiantes, y agrega las dos listas anteriores
// Finalmente, crea una nueva colección que contenga todos los estudiantes como elementos de la colección

//var studentsStartingWithJ =
//        DBContext.Students.Where(s => s.FirstName.StartsWith("J"));
//var studentsStartingWithA =
//    DBContext.Students.Where(s => s.FirstName.StartsWith("A"));

//var listOfLists = new List<IEnumerable<Student>>();
//listOfLists.Add(studentsStartingWithJ);
//listOfLists.Add(studentsStartingWithA);

//var studentsStartingWithJA =
//    listOfLists.SelectMany(s => s);

#endregion

#region Except
//7.- Obtén una primer colección de estudiantes cuyo nombre empiece con las letras "A, J y T"
// Después, obtén una segunda colección de estudiantes cuyo apellido empiece con las letras "S, B y W"
// Excluye los estudiantes cuyos nombres comiencen con "A", "J", o "T" de la lista de estudiantes

//var studentsStartingWithAJT =
//        DBContext.Students.Where(s => s.FirstName.StartsWith("A") || s.FirstName.StartsWith("J") || s.FirstName.StartsWith("T"));
//var studentsStartingWithSBW =
//    DBContext.Students.Where(s => s.LastName.StartsWith("S") || s.LastName.StartsWith("B") || s.LastName.StartsWith("W"));

//var studentsNotStartingWithAJT =
//    studentsStartingWithSBW.Except(studentsStartingWithAJT);

#endregion


#region Intersect
//8.- Obtén una primer colección de estudiantes cuyo nombre empiece con las letras "A, J y T"
// Después, obtén una segunda colección de estudiantes cuyo apellido empiece con las letras "S, B y W"
// Intersecta los estudiantes que se encuentre en ambas listas

//var studentsStartingWithAJT =
//        DBContext.Students.Where(s => s.FirstName.StartsWith("A") || s.FirstName.StartsWith("J") || s.FirstName.StartsWith("T"));
//var studentsStartingWithSBW =
//    DBContext.Students.Where(s => s.LastName.StartsWith("S") || s.LastName.StartsWith("B") || s.LastName.StartsWith("W"));

//var studentsStartingWithAJTAndSBW =
//    studentsStartingWithSBW.Intersect(studentsStartingWithAJT);

#endregion


#region Union

//9.- Obtén una primer colección de estudiantes cuyo nombre empiece con las letras "A, J y T"
// Después, obtén una segunda colección de estudiantes cuyo apellido empiece con las letras "S, B y W"
// Obtén la colección de estudiantes no repetidos de ambas colecciones

//var studentsStartingWithAJT =
//        DBContext.Students.Where(s => s.FirstName.StartsWith("A") || s.FirstName.StartsWith("J") || s.FirstName.StartsWith("T"));
//var studentsStartingWithSBW =
//    DBContext.Students.Where(s => s.LastName.StartsWith("S") || s.LastName.StartsWith("B") || s.LastName.StartsWith("W"));

//var studentsStartingWithAJTOrSBW =
//    studentsStartingWithSBW.Union(studentsStartingWithAJT);


#endregion


#region Reverse
//10.- Obtén la colección de todas las universidades ordenadas por nombre, y a continuación invierte el orden de la colección

//var universitiesOrderedByName =
//    DBContext.Universities.OrderBy(u => u.Name);

//var universitiesOrderedByNameReversed =
//    universitiesOrderedByName.Reverse();

#endregion


#endregion
//Printer.Print(countryQuantity);